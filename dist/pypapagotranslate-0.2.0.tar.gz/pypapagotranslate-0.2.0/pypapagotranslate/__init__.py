"""
Papago translate client for Python.
-----------------------------------
Made by SeolHa314
"""

__title__ = "pypapagotranslate"
__author__ = "SeolHa314"
__license__ = "MIT"
__version__ = "0.2.0"